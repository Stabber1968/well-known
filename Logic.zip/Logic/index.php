<?php
header('location:../Views/dashboard.php');